export const Woman =(
    <svg xmlns="http://www.w3.org/2000/svg" width="31" height="30" viewBox="0 0 31 30" fill="none">
<path d="M15.25 20C20.0825 20 24 16.0825 24 11.25C24 6.41751 20.0825 2.5 15.25 2.5C10.4175 2.5 6.5 6.41751 6.5 11.25C6.5 16.0825 10.4175 20 15.25 20Z" stroke="#757575" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M15.25 20V27.5" stroke="#757575" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M19 23.75H11.5" stroke="#757575" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
)