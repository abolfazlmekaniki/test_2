type apiURLtype = {
    [t in string] : string
}
export const APIURL:apiURLtype = {
    SuccessLogin : "/auth/signin/success",
    
}