const SelectDevices = () => {
  return (
    <div>SelectDevices</div>
  )
}

export default SelectDevices