import ConnectDevice from "./pages/ConnectDevice"

function App() {


  return (
   
  //  <LoginPage/>
  // <Device/>
  <ConnectDevice/>
   
  )
}

export default App
