export enum LoginActionTypes{
    LOGIN = "LOGIN"
}