import {QueryClient } from 'react-query'
export const QueryClientStore = new QueryClient()