export const ReactQueryKeys = {
    Login:"Login",
}